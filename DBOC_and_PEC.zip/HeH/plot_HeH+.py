#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Plot PEC+DBOC and DBOC curves for HeH+ in magnetic field (Physical Review A style)
Hollow markers, EPS output
Author: Timur
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
import os
import glob

# =============================================================================
# Physical constants and conversion factors
# =============================================================================
HARTREE_TO_CM1 = 219474.6313705

# =============================================================================
# Physical Review A style settings
# =============================================================================
rcParams.update({
    'text.usetex': True,
    'font.family': 'serif',
    'font.serif': ['Computer Modern Roman'],
    'font.size': 10,
    'axes.labelsize': 10,
    'axes.titlesize': 11,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'legend.handlelength': 2.5,
    'lines.linewidth': 0.5,
    'lines.markersize': 4,
    'lines.markeredgewidth': 0.5,
    'axes.linewidth': 0.8,
    'xtick.major.width': 0.8,
    'ytick.major.width': 0.8,
    'xtick.minor.width': 0.5,
    'ytick.minor.width': 0.5,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'xtick.top': True,
    'ytick.right': True,
    'figure.dpi': 300,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
})

# =============================================================================
# File mapping: suffix -> magnetic field label, marker, color
# =============================================================================
FIELD_CONFIG = {
    '_000':  {'label': r'$B_{\parallel}=0.0$',   'marker': 'o', 'color': '#000000'},
    '_001':  {'label': r'$B_{\parallel}=0.1$',   'marker': 's', 'color': '#1f77b4'},
    '_0015': {'label': r'$B_{\parallel}=0.15$',  'marker': '^', 'color': '#2ca02c'},
    '_002':  {'label': r'$B_{\parallel}=0.2$',   'marker': 'D', 'color': '#d62728'},
}

# =============================================================================
# Data loading function
# =============================================================================
def load_data(filepath):
    """Load two-column data file (distance in Bohr, energy in Hartree)"""
    data = np.loadtxt(filepath)
    return data[:, 0], data[:, 1]

def find_file(base_dir, prefix, suffix):
    """Find file with given prefix and suffix, preferring non-_000_1 variants"""
    # Сначала ищем основной файл (без _1)
    pattern_main = os.path.join(base_dir, f'{prefix}{suffix}.txt')
    files_main = glob.glob(pattern_main)
    if files_main:
        return files_main[0]
    # Если не найден, ищем вариант с _1 (для _000_1)
    pattern_alt = os.path.join(base_dir, f'{prefix}{suffix}_1.txt')
    files_alt = glob.glob(pattern_alt)
    if files_alt:
        return files_alt[0]
    return None

# =============================================================================
# Plotting functions
# =============================================================================
def plot_pec(base_dir, output_file='PEC_HeH_combined.eps'):
    """Plot PEC curves for HeH (energy in Hartree) with hollow markers"""
    fig, ax = plt.subplots(figsize=(3.5, 2.8))

    for suffix, config in FIELD_CONFIG.items():
        pattern = os.path.join(base_dir, f'PEC_CI_HeH{suffix}.txt')
        files = glob.glob(pattern)
        if not files:
            print(f"Warning: No file found for pattern {pattern}")
            continue
        filepath = files[0]
        try:
            r, energy = load_data(filepath)
            ax.plot(r, energy,
                   color=config['color'],
                   marker=config['marker'],
                   fillstyle='none',
                   markerfacecolor='none',
                   markevery=1,
                   label=config['label'],
                   linewidth=0.5,
                   markersize=1.5,
                   markeredgewidth=0.5)
        except Exception as e:
            print(f"Error loading {filepath}: {e}")

    ax.set_xlabel(r'Internuclear distance $R$ (Bohr)')
    ax.set_ylabel(r'Energy (Hartree)')

    # === Установить диапазон оси Y: от -3.0 до -2.8 хартри ===
    ax.set_ylim(-3.0, -2.8)

    # === Подпись HeH в верхнем правом углу ===
    ax.text(0.90, 0.90, r'HeH$^+$',
            transform=ax.transAxes,
            fontsize=10,
            fontweight='normal',
            va='top',
            ha='right',
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                     edgecolor='none', alpha=0.7))

    ax.legend(frameon=False, loc='lower right', handlelength=2.5)
    ax.grid(True, linestyle=':', alpha=0.3, linewidth=0.5)

    plt.tight_layout()
    plt.savefig(output_file, format='eps')
    plt.savefig(output_file.replace('.eps', '.png'), format='png', dpi=600)
    plt.close()
    print(f"Saved: {output_file}")
    
def plot_pec_dboc(base_dir, output_file='PEC_DBOC_HeH_combined.eps'):
    """Plot PEC+DBOC curves for HeH (energy in Hartree) with hollow markers"""
    fig, ax = plt.subplots(figsize=(3.5, 2.8))

    for suffix, config in FIELD_CONFIG.items():
        pattern = os.path.join(base_dir, f'PEC+DBOC_CI_HeH{suffix}.txt')
        files = glob.glob(pattern)
        if not files:
            print(f"Warning: No file found for pattern {pattern}")
            continue
        filepath = files[0]
        try:
            r, energy = load_data(filepath)
            ax.plot(r, energy,
                   color=config['color'],
                   marker=config['marker'],
                   fillstyle='none',
                   markerfacecolor='none',
                   markevery=1,
                   label=config['label'],
                   linewidth=0.5,
                   markersize=1.5,
                   markeredgewidth=0.5)
        except Exception as e:
            print(f"Error loading {filepath}: {e}")

    ax.set_xlabel(r'Internuclear distance $R$ (Bohr)')
    ax.set_ylabel(r'Energy (Hartree)')

    # === Установить диапазон оси Y: от -3.0 до -2.8 хартри ===
    ax.set_ylim(-3.0, -2.8)

    # === Подпись HeH в верхнем правом углу ===
    ax.text(0.90, 0.90, r'HeH$^+$',
            transform=ax.transAxes,
            fontsize=10,
            fontweight='normal',
            va='top',
            ha='right',
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                     edgecolor='none', alpha=0.7))

    ax.legend(frameon=False, loc='lower right', handlelength=2.5)
    ax.grid(True, linestyle=':', alpha=0.3, linewidth=0.5)

    plt.tight_layout()
    plt.savefig(output_file, format='eps')
    plt.savefig(output_file.replace('.eps', '.png'), format='png', dpi=600)
    plt.close()
    print(f"Saved: {output_file}")

def plot_dboc_only(base_dir, output_file='DBOC_HeH_combined.eps'):
    """Plot DBOC curves for HeH+ (energy in cm⁻¹) with hollow markers"""
    fig, ax = plt.subplots(figsize=(3.5, 2.8))

    for suffix, config in FIELD_CONFIG.items():
        filepath = find_file(base_dir, f'DBOC_CI_HeH', suffix)
        if filepath is None:
            print(f"Warning: No file found for DBOC_CI_HeH{suffix}")
            continue
        try:
            r, dboc_hartree = load_data(filepath)
            dboc_cm1 = dboc_hartree * HARTREE_TO_CM1
            ax.plot(r, dboc_cm1,
                   color=config['color'],
                   marker=config['marker'],
                   fillstyle='none',
                   markerfacecolor='none',
                   markevery=1,
                   label=config['label'],
                   linewidth=0.5,
                   markersize=1.5,
                   markeredgewidth=0.5)
        except Exception as e:
            print(f"Error loading {filepath}: {e}")

    ax.set_xlabel(r'Internuclear distance $R$ (Bohr)')
    ax.set_ylabel(r'DBOC (cm$^{-1}$)')
    
    # === Установить диапазон оси Y: от 340 до 380 см⁻¹ ===
    ax.set_ylim(90, 100)
    
    # === Подпись HeH⁺ в верхнем правом углу ===
    ax.text(0.90, 0.90, r'HeH$^+$',
            transform=ax.transAxes,
            fontsize=10,
            fontweight='normal',
            va='top',
            ha='right',
            bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                     edgecolor='none', alpha=0.7))

    ax.legend(frameon=False, loc='center right', handlelength=2.5)
    ax.grid(True, linestyle=':', alpha=0.3, linewidth=0.5)

    plt.tight_layout()
    plt.savefig(output_file, format='eps')
    plt.savefig(output_file.replace('.eps', '.png'), format='png', dpi=600)
    plt.close()
    print(f"Saved: {output_file}")

# =============================================================================
# Main execution
# =============================================================================
if __name__ == '__main__':
    base_directory = os.getcwd()

    if not os.path.exists(base_directory):
        print(f"Directory not found: {base_directory}")
        print("Please update 'base_directory' variable with the correct path.")
    else:
        print(f"Processing files in: {base_directory}")
        plot_pec(base_directory, output_file=os.path.join(base_directory, 'PEC_HeH_combined.eps'))
        plot_pec_dboc(base_directory, output_file=os.path.join(base_directory, 'PEC_DBOC_HeH_combined.eps'))
        plot_dboc_only(base_directory, output_file=os.path.join(base_directory, 'DBOC_HeH_combined.eps'))
        print("Plotting complete!")
